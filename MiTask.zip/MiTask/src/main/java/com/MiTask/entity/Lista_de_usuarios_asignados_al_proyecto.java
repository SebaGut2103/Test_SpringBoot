package com.MiTask.entity;

public class Lista_de_usuarios_asignados_al_proyecto {

}
