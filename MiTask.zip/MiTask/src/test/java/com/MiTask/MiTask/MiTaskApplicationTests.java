package com.MiTask.MiTask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
